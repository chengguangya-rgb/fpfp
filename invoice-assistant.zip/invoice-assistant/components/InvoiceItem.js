import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const categoryIcons = {
  '餐饮': '🍔',
  '交通': '🚗',
  '办公': '🏢',
  '差旅': '✈️',
  '其他': '📄',
};

export default function InvoiceItem({ invoice, batchMode, selected, onToggle, onDelete }) {
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return `${date.getMonth() + 1}月${date.getDate()}日`;
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity 
        style={[styles.content, batchMode && styles.contentBatch]} 
        onPress={onToggle}
      >
        {batchMode && (
          <View style={[styles.checkbox, selected && styles.checkboxSelected]}>
            {selected && <Ionicons name="checkmark" size={16} color="#fff" />}
          </View>
        )}

        <View style={styles.iconContainer}>
          <Text style={styles.icon}>{categoryIcons[invoice.category] || '📄'}</Text>
        </View>
        
        <View style={styles.info}>
          <Text style={styles.seller} numberOfLines={1}>{invoice.seller}</Text>
          <View style={styles.metaRow}>
            <Text style={styles.amount}>¥{invoice.amount}</Text>
            <Text style={styles.date}>{formatDate(invoice.date)}</Text>
          </View>
        </View>

        <View style={styles.rightSection}>
          <View style={[styles.categoryBadge, { backgroundColor: getCategoryColor(invoice.category) }]}>
            <Text style={styles.categoryText}>{invoice.category}</Text>
          </View>
          
          {!batchMode && (
            <View style={styles.statusContainer}>
              <View style={[styles.statusBadge, invoice.reimbursed ? styles.statusReimbursed : styles.statusPending]}>
                <Text style={[styles.statusText, invoice.reimbursed ? styles.statusTextReimbursed : styles.statusTextPending]}>
                  {invoice.reimbursed ? '已报销' : '未报销'}
                </Text>
              </View>
              <TouchableOpacity style={styles.deleteBtn} onPress={onDelete}>
                <Ionicons name="trash-outline" size={18} color="#FF3B30" />
              </TouchableOpacity>
            </View>
          )}
        </View>
      </TouchableOpacity>
    </View>
  );
}

const getCategoryColor = (category) => {
  const colors = {
    '餐饮': '#FFF3E0',
    '交通': '#E3F2FD',
    '办公': '#E8F5E9',
    '差旅': '#F3E5F5',
    '其他': '#F5F5F5',
  };
  return colors[category] || '#F5F5F5';
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 3,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  contentBatch: {
    paddingLeft: 12,
  },
  checkbox: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#ddd',
    marginRight: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  checkboxSelected: {
    backgroundColor: '#007AFF',
    borderColor: '#007AFF',
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#f5f5f5',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  icon: {
    fontSize: 24,
  },
  info: {
    flex: 1,
  },
  seller: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 6,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  amount: {
    fontSize: 16,
    fontWeight: '700',
    color: '#007AFF',
  },
  date: {
    fontSize: 13,
    color: '#999',
  },
  rightSection: {
    alignItems: 'flex-end',
    gap: 6,
  },
  categoryBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  categoryText: {
    fontSize: 12,
    fontWeight: '500',
    color: '#666',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
  },
  statusPending: {
    backgroundColor: '#FFF3E0',
  },
  statusReimbursed: {
    backgroundColor: '#E8F5E9',
  },
  statusText: {
    fontSize: 11,
    fontWeight: '500',
  },
  statusTextPending: {
    color: '#FF9500',
  },
  statusTextReimbursed: {
    color: '#34C759',
  },
  deleteBtn: {
    padding: 4,
  },
});
