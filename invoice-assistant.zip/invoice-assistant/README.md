# 发票助手

一款简洁的本地发票管理APP，帮助您整理、存储和追踪发票报销状态。

## 功能特性

✅ **添加发票** - 选择PDF文件，记录发票信息
✅ **状态管理** - 标记发票为"已报销"或"未报销"
✅ **筛选查看** - 按状态筛选发票（全部/未报销/已报销）
✅ **本地存储** - 数据保存在手机本地，无需联网
✅ **简洁界面** - 清晰直观，操作简单

## 使用方法

1. 点击右下角 **+** 按钮添加发票
2. 选择PDF文件并输入金额（可选）
3. 点击发票条目切换报销状态
4. 长按或点击删除按钮移除发票

## 技术栈

- React Native
- Expo
- AsyncStorage（本地存储）

## 项目结构

```
invoice-assistant/
├── App.js              # 主入口
├── components/
│   └── InvoiceItem.js  # 发票列表项组件
├── utils/
│   └── storage.js      # 本地存储工具
├── app.json            # Expo配置
└── package.json        # 依赖配置
```

## 构建APK

### 方法1：使用 Expo EAS Build（推荐）

1. 安装 EAS CLI:
```bash
npm install -g eas-cli
```

2. 登录 Expo 账号:
```bash
eas login
```

3. 构建 APK:
```bash
eas build -p android --profile preview
```

### 方法2：本地构建（需要Android SDK）

1. 安装 Android Studio 和 Android SDK
2. 配置 ANDROID_SDK_ROOT 环境变量
3. 构建:
```bash
expo prebuild
cd android
./gradlew assembleRelease
```

### 方法3：使用 Expo Go 直接运行

1. 手机安装 Expo Go APP
2. 运行:
```bash
npx expo start
```
3. 扫描二维码在手机上预览

## 截图

（截图待添加）

## 版本历史

### v1.0.0
- 初始版本
- 支持添加、删除、标记发票
- 本地数据存储
