import AsyncStorage from '@react-native-async-storage/async-storage';

const INVOICES_KEY = '@invoices';
const CATEGORIES_KEY = '@categories';

// 默认分类规则
const defaultCategories = {
  '餐饮': ['餐饮', '餐厅', '饭店', '火锅', '烧烤', '咖啡', '奶茶', '外卖', '美食', '海底捞', '肯德基', '麦当劳'],
  '交通': ['滴滴', '出租', '打车', '地铁', '公交', '加油', '停车', '高速', 'ETC', '出行'],
  '办公': ['办公', '文具', '打印', '耗材', '京东', '淘宝', '天猫', '电脑', '手机', '设备'],
  '差旅': ['酒店', '住宿', '机票', '火车票', '高铁', '飞机', '旅行', '旅游', '出差'],
};

// 获取所有发票
export const getInvoices = async () => {
  try {
    const jsonValue = await AsyncStorage.getItem(INVOICES_KEY);
    return jsonValue != null ? JSON.parse(jsonValue) : [];
  } catch (e) {
    console.error('获取发票失败:', e);
    return [];
  }
};

// 保存发票
export const saveInvoice = async (invoice) => {
  try {
    const invoices = await getInvoices();
    const newInvoice = {
      ...invoice,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      reimbursed: false,
    };
    
    // 如果没有分类，自动分类
    if (!newInvoice.category || newInvoice.category === '其他') {
      newInvoice.category = classifyInvoice(newInvoice.seller, newInvoice.content);
    }
    
    const updatedInvoices = [newInvoice, ...invoices];
    await AsyncStorage.setItem(INVOICES_KEY, JSON.stringify(updatedInvoices));
    return newInvoice;
  } catch (e) {
    console.error('保存发票失败:', e);
    throw e;
  }
};

// 删除发票
export const deleteInvoice = async (id) => {
  try {
    const invoices = await getInvoices();
    const updatedInvoices = invoices.filter(inv => inv.id !== id);
    await AsyncStorage.setItem(INVOICES_KEY, JSON.stringify(updatedInvoices));
  } catch (e) {
    console.error('删除发票失败:', e);
    throw e;
  }
};

// 切换报销状态
export const toggleReimbursed = async (id) => {
  try {
    const invoices = await getInvoices();
    const updatedInvoices = invoices.map(inv => 
      inv.id === id ? { ...inv, reimbursed: !inv.reimbursed } : inv
    );
    await AsyncStorage.setItem(INVOICES_KEY, JSON.stringify(updatedInvoices));
  } catch (e) {
    console.error('更新状态失败:', e);
    throw e;
  }
};

// 更新发票
export const updateInvoice = async (id, updates) => {
  try {
    const invoices = await getInvoices();
    const updatedInvoices = invoices.map(inv => 
      inv.id === id ? { ...inv, ...updates } : inv
    );
    await AsyncStorage.setItem(INVOICES_KEY, JSON.stringify(updatedInvoices));
  } catch (e) {
    console.error('更新发票失败:', e);
    throw e;
  }
};

// 智能分类
export const classifyInvoice = (seller = '', content = '') => {
  const text = (seller + ' ' + content).toLowerCase();
  
  for (const [category, keywords] of Object.entries(defaultCategories)) {
    for (const keyword of keywords) {
      if (text.includes(keyword.toLowerCase())) {
        return category;
      }
    }
  }
  
  return '其他';
};

// 获取分类规则
export const getCategories = async () => {
  try {
    const jsonValue = await AsyncStorage.getItem(CATEGORIES_KEY);
    return jsonValue != null ? JSON.parse(jsonValue) : defaultCategories;
  } catch (e) {
    return defaultCategories;
  }
};

// 保存分类规则
export const saveCategories = async (categories) => {
  try {
    await AsyncStorage.setItem(CATEGORIES_KEY, JSON.stringify(categories));
  } catch (e) {
    console.error('保存分类规则失败:', e);
    throw e;
  }
};

// 获取未报销的发票
export const getPendingInvoices = async () => {
  const invoices = await getInvoices();
  return invoices.filter(inv => !inv.reimbursed);
};

// 获取统计信息
export const getStatistics = async () => {
  const invoices = await getInvoices();
  const pending = invoices.filter(inv => !inv.reimbursed);
  const reimbursed = invoices.filter(inv => inv.reimbursed);
  
  return {
    total: invoices.length,
    pendingCount: pending.length,
    reimbursedCount: reimbursed.length,
    pendingAmount: pending.reduce((sum, inv) => sum + (parseFloat(inv.amount) || 0), 0),
    reimbursedAmount: reimbursed.reduce((sum, inv) => sum + (parseFloat(inv.amount) || 0), 0),
    totalAmount: invoices.reduce((sum, inv) => sum + (parseFloat(inv.amount) || 0), 0),
  };
};

// 按分类统计
export const getCategoryStats = async () => {
  const invoices = await getInvoices();
  const stats = {};
  
  for (const inv of invoices) {
    if (!stats[inv.category]) {
      stats[inv.category] = { count: 0, amount: 0 };
    }
    stats[inv.category].count++;
    stats[inv.category].amount += parseFloat(inv.amount) || 0;
  }
  
  return stats;
};
