import React, { useState, useEffect } from 'react';
import { 
  StyleSheet, View, FlatList, TouchableOpacity, Alert, 
  Modal, TextInput, Text, SafeAreaView, ScrollView 
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as ZipArchive from 'react-native-zip-archive';
import InvoiceItem from './components/InvoiceItem';
import { 
  getInvoices, saveInvoice, deleteInvoice, toggleReimbursed,
  getCategories, classifyInvoice 
} from './utils/storage';

export default function App() {
  const [invoices, setInvoices] = useState([]);
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [modalVisible, setModalVisible] = useState(false);
  const [batchMode, setBatchMode] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);
  
  // 添加发票表单
  const [pdfUri, setPdfUri] = useState('');
  const [pdfName, setPdfName] = useState('');
  const [seller, setSeller] = useState('');
  const [buyer, setBuyer] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('');

  useEffect(() => {
    loadInvoices();
  }, []);

  const loadInvoices = async () => {
    const data = await getInvoices();
    setInvoices(data);
  };

  // 自动识别发票信息（模拟）
  const recognizeInvoice = (fileName, textContent = '') => {
    const recognition = {
      seller: '',
      buyer: '',
      amount: '',
      date: new Date().toISOString().split('T')[0],
      content: '',
      category: '其他'
    };

    // 从文件名提取信息
    if (fileName.includes('餐饮') || fileName.includes('餐厅') || fileName.includes('火锅')) {
      recognition.category = '餐饮';
      recognition.content = '餐饮服务';
      recognition.seller = '餐饮公司';
    } else if (fileName.includes('滴滴') || fileName.includes('出行') || fileName.includes('交通')) {
      recognition.category = '交通';
      recognition.content = '交通出行';
      recognition.seller = '滴滴出行';
    } else if (fileName.includes('办公') || fileName.includes('文具') || fileName.includes('京东')) {
      recognition.category = '办公';
      recognition.content = '办公用品';
      recognition.seller = '京东商城';
    } else if (fileName.includes('酒店') || fileName.includes('住宿') || fileName.includes('机票')) {
      recognition.category = '差旅';
      recognition.content = '差旅住宿';
      recognition.seller = '酒店集团';
    }

    // 尝试提取金额（从文件名中的数字）
    const amountMatch = fileName.match(/(\d+)/);
    if (amountMatch) {
      recognition.amount = amountMatch[1];
    }

    return recognition;
  };

  const handleAddInvoice = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: 'application/pdf',
        copyToCacheDirectory: true,
      });

      if (result.canceled === false) {
        const file = result.assets[0];
        setPdfUri(file.uri);
        setPdfName(file.name);
        
        // 自动识别
        const recognized = recognizeInvoice(file.name);
        setSeller(recognized.seller);
        setBuyer(recognized.buyer);
        setAmount(recognized.amount);
        setDate(recognized.date);
        setContent(recognized.content);
        setCategory(recognized.category);
        
        setModalVisible(true);
      }
    } catch (err) {
      Alert.alert('错误', '选择文件失败：' + err.message);
    }
  };

  const handleSaveInvoice = async () => {
    if (!pdfName) {
      Alert.alert('提示', '请先选择PDF文件');
      return;
    }

    try {
      // 复制PDF到持久化存储
      const fileName = `invoice_${Date.now()}.pdf`;
      const newUri = FileSystem.documentDirectory + fileName;
      await FileSystem.copyAsync({ from: pdfUri, to: newUri });

      await saveInvoice({
        fileName: pdfName,
        pdfUri: newUri,
        seller: seller || '未知销售方',
        buyer: buyer || '未知购买方',
        amount: amount || '0',
        date: date || new Date().toISOString(),
        content: content || '未识别内容',
        category: category || '其他',
      });

      // 重置表单
      setModalVisible(false);
      setPdfUri('');
      setPdfName('');
      setSeller('');
      setBuyer('');
      setAmount('');
      setDate('');
      setContent('');
      setCategory('');
      
      loadInvoices();
      Alert.alert('成功', '发票已保存');
    } catch (e) {
      Alert.alert('错误', '保存失败：' + e.message);
    }
  };

  const handleToggleReimbursed = async (id) => {
    await toggleReimbursed(id);
    loadInvoices();
  };

  const handleDelete = async (id) => {
    Alert.alert(
      '删除确认',
      '确定要删除这张发票吗？',
      [
        { text: '取消', style: 'cancel' },
        { 
          text: '删除', 
          style: 'destructive',
          onPress: async () => {
            await deleteInvoice(id);
            loadInvoices();
          }
        }
      ]
    );
  };

  // 批量选择
  const handleToggleSelect = (id) => {
    setSelectedItems(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id)
        : [...prev, id]
    );
  };

  // 打包下载
  const handleBatchDownload = async () => {
    if (selectedItems.length === 0) {
      Alert.alert('提示', '请先选择发票');
      return;
    }

    try {
      const selectedInvoices = invoices.filter(inv => selectedItems.includes(inv.id));
      const filePaths = selectedInvoices.map(inv => inv.pdfUri);
      
      // 创建ZIP
      const zipPath = FileSystem.cacheDirectory + `报销包_${Date.now()}.zip`;
      await ZipArchive.zip(filePaths, zipPath);
      
      // 分享ZIP
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(zipPath);
      }
      
      // 退出批量模式
      setBatchMode(false);
      setSelectedItems([]);
    } catch (e) {
      Alert.alert('错误', '打包失败：' + e.message);
    }
  };

  // 筛选
  const filteredInvoices = invoices.filter(inv => {
    const typeMatch = filterType === 'all' || inv.category === filterType;
    const statusMatch = filterStatus === 'all' || 
      (filterStatus === 'pending' && !inv.reimbursed) ||
      (filterStatus === 'reimbursed' && inv.reimbursed);
    return typeMatch && statusMatch;
  });

  // 计算未报销总额
  const pendingTotal = invoices
    .filter(inv => !inv.reimbursed)
    .reduce((sum, inv) => sum + (parseFloat(inv.amount) || 0), 0);

  const categories = ['all', '餐饮', '交通', '办公', '差旅', '其他'];

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="auto" />
      
      {/* 标题栏 */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>💰 发票助手</Text>
        <Text style={styles.headerSubtitle}>
          共 {invoices.length} 张 · 未报销 ¥{pendingTotal.toFixed(2)}
        </Text>
      </View>

      {/* 类型筛选 */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.typeFilterContainer}>
        {categories.map(cat => (
          <TouchableOpacity 
            key={cat}
            style={[styles.typeFilterBtn, filterType === cat && styles.typeFilterBtnActive]}
            onPress={() => setFilterType(cat)}
          >
            <Text style={[styles.typeFilterText, filterType === cat && styles.typeFilterTextActive]}>
              {cat === 'all' ? '全部' : cat}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* 状态筛选 */}
      <View style={styles.statusFilterContainer}>
        {['all', 'pending', 'reimbursed'].map(status => (
          <TouchableOpacity 
            key={status}
            style={[styles.statusFilterBtn, filterStatus === status && styles.statusFilterBtnActive]}
            onPress={() => setFilterStatus(status)}
          >
            <Text style={[styles.statusFilterText, filterStatus === status && styles.statusFilterTextActive]}>
              {status === 'all' ? '全部' : status === 'pending' ? '未报销' : '已报销'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* 发票列表 */}
      <FlatList
        data={filteredInvoices}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <InvoiceItem 
            invoice={item}
            batchMode={batchMode}
            selected={selectedItems.includes(item.id)}
            onToggle={batchMode ? () => handleToggleSelect(item.id) : () => handleToggleReimbursed(item.id)}
            onDelete={() => handleDelete(item.id)}
          />
        )}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="document-text-outline" size={64} color="#ccc" />
            <Text style={styles.emptyText}>暂无发票</Text>
            <Text style={styles.emptySubtext}>点击右下角添加</Text>
          </View>
        }
      />

      {/* 底部按钮 */}
      {batchMode ? (
        <View style={styles.batchBar}>
          <Text style={styles.batchText}>已选 {selectedItems.length} 张</Text>
          <TouchableOpacity style={styles.batchDownloadBtn} onPress={handleBatchDownload}>
            <Text style={styles.batchDownloadText}>📦 打包下载</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => { setBatchMode(false); setSelectedItems([]); }}>
            <Text style={styles.cancelText}>取消</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.bottomBar}>
          <TouchableOpacity style={styles.batchBtn} onPress={() => setBatchMode(true)}>
            <Text style={styles.batchBtnText}>📦 批量选择</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.addButton} onPress={handleAddInvoice}>
            <Ionicons name="add" size={32} color="#fff" />
          </TouchableOpacity>
        </View>
      )}

      {/* 添加发票弹窗 */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>📤 添加发票</Text>
            
            <Text style={styles.fileName}>📄 {pdfName}</Text>
            
            <ScrollView style={styles.formScroll}>
              <Text style={styles.label}>销售方</Text>
              <TextInput style={styles.input} value={seller} onChangeText={setSeller} placeholder="自动识别..." />
              
              <Text style={styles.label}>购买方</Text>
              <TextInput style={styles.input} value={buyer} onChangeText={setBuyer} placeholder="自动识别..." />
              
              <Text style={styles.label}>金额</Text>
              <TextInput style={styles.input} value={amount} onChangeText={setAmount} placeholder="¥0.00" keyboardType="numeric" />
              
              <Text style={styles.label}>开票日期</Text>
              <TextInput style={styles.input} value={date} onChangeText={setDate} placeholder="2024-01-01" />
              
              <Text style={styles.label}>发票内容</Text>
              <TextInput style={styles.input} value={content} onChangeText={setContent} placeholder="发票内容..." />
              
              <Text style={styles.label}>分类</Text>
              <View style={styles.categoryContainer}>
                {['餐饮', '交通', '办公', '差旅', '其他'].map(cat => (
                  <TouchableOpacity 
                    key={cat}
                    style={[styles.categoryBtn, category === cat && styles.categoryBtnActive]}
                    onPress={() => setCategory(cat)}
                  >
                    <Text style={[styles.categoryText, category === cat && styles.categoryTextActive]}>{cat}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
            
            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setModalVisible(false)}>
                <Text style={styles.cancelBtnText}>取消</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={handleSaveInvoice}>
                <Text style={styles.saveBtnText}>保存</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f5f5f5' },
  header: { backgroundColor: '#fff', paddingTop: 50, paddingHorizontal: 20, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: '#eee' },
  headerTitle: { fontSize: 28, fontWeight: 'bold', color: '#333' },
  headerSubtitle: { fontSize: 14, color: '#999', marginTop: 4 },
  
  typeFilterContainer: { backgroundColor: '#fff', paddingVertical: 12, paddingHorizontal: 16, borderBottomWidth: 1, borderBottomColor: '#eee' },
  typeFilterBtn: { paddingHorizontal: 16, paddingVertical: 8, marginRight: 8, borderRadius: 16, backgroundColor: '#f0f0f0' },
  typeFilterBtnActive: { backgroundColor: '#007AFF' },
  typeFilterText: { fontSize: 14, color: '#666' },
  typeFilterTextActive: { color: '#fff', fontWeight: '600' },
  
  statusFilterContainer: { flexDirection: 'row', padding: 12, backgroundColor: '#fff', gap: 8 },
  statusFilterBtn: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 8, backgroundColor: '#f0f0f0' },
  statusFilterBtnActive: { backgroundColor: '#34C759' },
  statusFilterText: { fontSize: 14, color: '#666', fontWeight: '500' },
  statusFilterTextActive: { color: '#fff' },
  
  list: { padding: 16 },
  empty: { alignItems: 'center', marginTop: 100 },
  emptyText: { fontSize: 18, color: '#999', marginTop: 16 },
  emptySubtext: { fontSize: 14, color: '#bbb', marginTop: 8 },
  
  bottomBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 16, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#eee' },
  batchBtn: { paddingHorizontal: 20, paddingVertical: 12, backgroundColor: '#f0f0f0', borderRadius: 8 },
  batchBtnText: { fontSize: 14, color: '#333', fontWeight: '500' },
  addButton: { width: 56, height: 56, borderRadius: 28, backgroundColor: '#007AFF', justifyContent: 'center', alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 6, elevation: 8 },
  
  batchBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 16, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#eee' },
  batchText: { fontSize: 16, fontWeight: '600', color: '#333' },
  batchDownloadBtn: { backgroundColor: '#007AFF', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 8 },
  batchDownloadText: { color: '#fff', fontWeight: '600' },
  cancelText: { color: '#999', fontSize: 14 },
  
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modalContent: { backgroundColor: '#fff', borderRadius: 16, padding: 24, maxHeight: '80%' },
  modalTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 16, color: '#333' },
  fileName: { fontSize: 14, color: '#666', marginBottom: 16, padding: 12, backgroundColor: '#f5f5f5', borderRadius: 8 },
  formScroll: { maxHeight: 400 },
  label: { fontSize: 14, color: '#666', marginBottom: 6, marginTop: 12 },
  input: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8, padding: 12, fontSize: 16 },
  categoryContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 16 },
  categoryBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 16, backgroundColor: '#f0f0f0' },
  categoryBtnActive: { backgroundColor: '#007AFF' },
  categoryText: { color: '#666' },
  categoryTextActive: { color: '#fff', fontWeight: '600' },
  modalButtons: { flexDirection: 'row', gap: 12, marginTop: 16 },
  cancelBtn: { flex: 1, paddingVertical: 12, borderRadius: 8, backgroundColor: '#f0f0f0', alignItems: 'center' },
  saveBtn: { flex: 1, paddingVertical: 12, borderRadius: 8, backgroundColor: '#007AFF', alignItems: 'center' },
  cancelBtnText: { color: '#666', fontWeight: '600' },
  saveBtnText: { color: '#fff', fontWeight: '600' },
});
